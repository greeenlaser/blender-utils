bl_info = {
    "name": "Add Alpha To Texture",
    "author": "greenlaser",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "Shader Editor > Add",
    "description": "Combines image/color data with alpha for materials or packed Blender images",
    "category": "Node",
}

import bpy

from bpy.props import (
    EnumProperty,
    IntProperty,
    StringProperty,
)


MATERIAL_GROUP_NAME = ".Add Alpha To Texture Material"
IMAGE_GROUP_NAME = ".Add Alpha To Texture Image"


# ============================================================
# Internal groups
# ============================================================

def create_material_group():
    group = bpy.data.node_groups.get(MATERIAL_GROUP_NAME)

    if group is not None:
        return group

    group = bpy.data.node_groups.new(
        MATERIAL_GROUP_NAME,
        "ShaderNodeTree"
    )

    image_input = group.interface.new_socket(
        name="Image",
        in_out='INPUT',
        socket_type='NodeSocketColor'
    )

    image_input.default_value = (
        1.0,
        1.0,
        1.0,
        1.0
    )

    alpha_input = group.interface.new_socket(
        name="Alpha",
        in_out='INPUT',
        socket_type='NodeSocketFloat'
    )

    alpha_input.default_value = 1.0
    alpha_input.min_value = 0.0
    alpha_input.max_value = 1.0

    group.interface.new_socket(
        name="Color",
        in_out='OUTPUT',
        socket_type='NodeSocketColor'
    )

    group.interface.new_socket(
        name="Alpha",
        in_out='OUTPUT',
        socket_type='NodeSocketFloat'
    )

    group_input = group.nodes.new("NodeGroupInput")
    group_input.location = (-200, 0)

    group_output = group.nodes.new("NodeGroupOutput")
    group_output.location = (200, 0)

    group.links.new(
        group_input.outputs["Image"],
        group_output.inputs["Color"]
    )

    group.links.new(
        group_input.outputs["Alpha"],
        group_output.inputs["Alpha"]
    )

    return group


def create_image_group():
    group = bpy.data.node_groups.get(
        IMAGE_GROUP_NAME
    )

    if group is not None:
        #
        # Ensure Image mode has absolutely no outputs.
        #
        for item in list(group.interface.items_tree):
            if (
                item.item_type == 'SOCKET'
                and item.in_out == 'OUTPUT'
            ):
                group.interface.remove(item)

        return group

    group = bpy.data.node_groups.new(
        IMAGE_GROUP_NAME,
        "ShaderNodeTree"
    )

    image_input = group.interface.new_socket(
        name="Image",
        in_out='INPUT',
        socket_type='NodeSocketColor'
    )

    image_input.default_value = (
        1.0,
        1.0,
        1.0,
        1.0
    )

    alpha_input = group.interface.new_socket(
        name="Alpha",
        in_out='INPUT',
        socket_type='NodeSocketFloat'
    )

    alpha_input.default_value = 1.0
    alpha_input.min_value = 0.0
    alpha_input.max_value = 1.0

    group_input = group.nodes.new(
        "NodeGroupInput"
    )

    group_input.location = (
        -200,
        0
    )

    return group


# ============================================================
# Helpers
# ============================================================

def get_link_data(socket):
    if socket is None or not socket.is_linked:
        return None

    link = socket.links[0]

    return (
        link.from_node,
        link.from_socket.name
    )


def restore_link(tree, target_socket, link_data):
    if link_data is None:
        return

    source_node, source_socket_name = link_data

    source_socket = source_node.outputs.get(
        source_socket_name
    )

    if source_socket is None:
        return

    try:
        tree.links.new(
            source_socket,
            target_socket
        )
    except Exception:
        pass


def get_source_image(socket):
    if socket is None or not socket.is_linked:
        return None, None

    link = socket.links[0]

    source_node = link.from_node
    source_socket = link.from_socket

    if source_node.bl_idname != "ShaderNodeTexImage":
        return None, None

    if source_node.image is None:
        return None, None

    return source_node.image, source_socket.name


def read_alpha_from_pixel(
    pixels,
    index,
    source_socket_name,
    channel_mode
):
    r = pixels[index + 0]
    g = pixels[index + 1]
    b = pixels[index + 2]
    a = pixels[index + 3]

    #
    # If the user explicitly connected the Alpha output,
    # use the actual texture alpha.
    #

    if source_socket_name == "Alpha":
        return a

    if channel_mode == 'RED':
        return r

    if channel_mode == 'GREEN':
        return g

    if channel_mode == 'BLUE':
        return b

    if channel_mode == 'ALPHA':
        return a

    #
    # Luminance.
    #
    # For grayscale masks this is identical to R/G/B.
    #

    return (
        r * 0.2126
        + g * 0.7152
        + b * 0.0722
    )


# ============================================================
# Mode switching
# ============================================================

def update_output_type(self, context):
    tree = self.id_data

    if tree is None:
        return

    #
    # Preserve current input links.
    #

    image_link = get_link_data(
        self.inputs.get("Image")
    )

    alpha_link = get_link_data(
        self.inputs.get("Alpha")
    )

    #
    # Preserve constants.
    #

    image_value = None
    alpha_value = None

    if self.inputs.get("Image") is not None:
        image_value = tuple(
            self.inputs["Image"].default_value
        )

    if self.inputs.get("Alpha") is not None:
        alpha_value = self.inputs["Alpha"].default_value

    #
    # Swap implementation.
    #

    if self.output_type == 'MATERIAL':
        self.node_tree = create_material_group()

    else:
        self.node_tree = create_image_group()

    #
    # Restore constants.
    #

    image_socket = self.inputs.get("Image")
    alpha_socket = self.inputs.get("Alpha")

    if (
        image_socket is not None
        and image_value is not None
        and not image_socket.is_linked
    ):
        image_socket.default_value = image_value

    if (
        alpha_socket is not None
        and alpha_value is not None
        and not alpha_socket.is_linked
    ):
        alpha_socket.default_value = alpha_value

    #
    # Restore links.
    #

    if image_socket is not None:
        restore_link(
            tree,
            image_socket,
            image_link
        )

    if alpha_socket is not None:
        restore_link(
            tree,
            alpha_socket,
            alpha_link
        )


# ============================================================
# Generate packed Blender Image
# ============================================================

class SHADER_OT_generate_alpha_image(
    bpy.types.Operator
):
    bl_idname = "shader.generate_add_alpha_image"
    bl_label = "Generate / Update Image"
    bl_description = (
        "Generate a real RGBA Blender Image datablock "
        "and pack it into the blend file"
    )

    node_name: StringProperty()

    def execute(self, context):
        tree = context.space_data.edit_tree

        if tree is None:
            return {'CANCELLED'}

        node = tree.nodes.get(
            self.node_name
        )

        if node is None:
            self.report(
                {'ERROR'},
                "Add Alpha To Texture node not found"
            )

            return {'CANCELLED'}

        image_socket = node.inputs.get("Image")
        alpha_socket = node.inputs.get("Alpha")

        if image_socket is None or alpha_socket is None:
            self.report(
                {'ERROR'},
                "Node inputs are invalid"
            )

            return {'CANCELLED'}

        #
        # Resolve source images.
        #

        color_image, color_source_socket = get_source_image(
            image_socket
        )

        alpha_image, alpha_source_socket = get_source_image(
            alpha_socket
        )

        #
        # We currently support:
        #
        # Image:
        #   constant color
        #   Image Texture
        #
        # Alpha:
        #   constant float
        #   Image Texture Color
        #   Image Texture Alpha
        #

        if (
            image_socket.is_linked
            and color_image is None
        ):
            self.report(
                {'ERROR'},
                "Image input currently supports a constant color "
                "or direct Image Texture connection"
            )

            return {'CANCELLED'}

        if (
            alpha_socket.is_linked
            and alpha_image is None
        ):
            self.report(
                {'ERROR'},
                "Alpha input currently supports a constant value "
                "or direct Image Texture connection"
            )

            return {'CANCELLED'}

        #
        # Determine output resolution.
        #
        # Prefer the Image source.
        # Then Alpha source.
        # Otherwise use node Width/Height.
        #

        if color_image is not None:
            width = int(color_image.size[0])
            height = int(color_image.size[1])

        elif alpha_image is not None:
            width = int(alpha_image.size[0])
            height = int(alpha_image.size[1])

        else:
            width = node.image_width
            height = node.image_height

        if width <= 0 or height <= 0:
            self.report(
                {'ERROR'},
                "Invalid image dimensions"
            )

            return {'CANCELLED'}

        #
        # For now image-backed sources must match.
        #

        if (
            color_image is not None
            and alpha_image is not None
            and (
                color_image.size[0] != alpha_image.size[0]
                or color_image.size[1] != alpha_image.size[1]
            )
        ):
            self.report(
                {'ERROR'},
                "Image and Alpha textures must currently "
                "have matching dimensions"
            )

            return {'CANCELLED'}

        pixel_count = width * height

        #
        # Read source image pixels.
        #

        color_pixels = None
        alpha_pixels = None

        if color_image is not None:
            color_pixels = list(
                color_image.pixels[:]
            )

        if alpha_image is not None:
            alpha_pixels = list(
                alpha_image.pixels[:]
            )

        #
        # Constant values.
        #

        constant_color = tuple(
            image_socket.default_value
        )

        constant_alpha = float(
            alpha_socket.default_value
        )

        #
        # Build RGBA output.
        #

        final_pixels = [0.0] * (
            pixel_count * 4
        )

        for pixel in range(pixel_count):
            index = pixel * 4

            #
            # RGB
            #

            if color_pixels is not None:
                r = color_pixels[index + 0]
                g = color_pixels[index + 1]
                b = color_pixels[index + 2]

            else:
                r = constant_color[0]
                g = constant_color[1]
                b = constant_color[2]

            #
            # Alpha
            #

            if alpha_pixels is not None:
                alpha = read_alpha_from_pixel(
                    alpha_pixels,
                    index,
                    alpha_source_socket,
                    node.alpha_channel
                )

            else:
                alpha = constant_alpha

            alpha = max(
                0.0,
                min(
                    1.0,
                    alpha
                )
            )

            final_pixels[index + 0] = r
            final_pixels[index + 1] = g
            final_pixels[index + 2] = b
            final_pixels[index + 3] = alpha

        #
        # Name
        #

        image_name = node.image_name.strip()

        if not image_name:
            self.report(
                {'ERROR'},
                "Image Name cannot be empty"
            )

            return {'CANCELLED'}

        #
        # Create or update bpy.data.images image.
        #

        output_image = bpy.data.images.get(
            image_name
        )

        if output_image is None:
            output_image = bpy.data.images.new(
                name=image_name,
                width=width,
                height=height,
                alpha=True,
                float_buffer=False
            )

        elif (
            output_image.size[0] != width
            or output_image.size[1] != height
        ):
            output_image.scale(
                width,
                height
            )

        #
        # Make sure Blender treats it as a color texture.
        #

        try:
            output_image.colorspace_settings.name = 'sRGB'
        except Exception:
            pass

        output_image.pixels.foreach_set(
            final_pixels
        )

        output_image.update()

        #
        # Store image inside the .blend.
        #

        try:
            output_image.pack()
        except RuntimeError:
            pass

        node.generated_image_name = (
            output_image.name
        )

        self.report(
            {'INFO'},
            f"Generated packed image '{output_image.name}' "
            f"({width}x{height})"
        )

        return {'FINISHED'}


# ============================================================
# Visible node
# ============================================================

class ShaderNodeAddAlphaToTexture(
    bpy.types.ShaderNodeCustomGroup
):
    bl_idname = "ShaderNodeAddAlphaToTexture"
    bl_label = "Add Alpha To Texture"
    bl_icon = 'IMAGE_DATA'

    output_type: EnumProperty(
        name="Output Type",
        items=[
            (
                'MATERIAL',
                "Material",
                "Output Color and Alpha for a material"
            ),
            (
                'IMAGE',
                "Image",
                "Generate a packed Blender image"
            ),
        ],
        default='MATERIAL',
        update=update_output_type
    )

    image_name: StringProperty(
        name="Image Name",
        description="Name of the generated Blender image",
        default="alpha_texture"
    )

    image_width: IntProperty(
        name="Width",
        description=(
            "Output width when neither input "
            "provides an image resolution"
        ),
        default=1024,
        min=1,
        max=16384
    )

    image_height: IntProperty(
        name="Height",
        description=(
            "Output height when neither input "
            "provides an image resolution"
        ),
        default=1024,
        min=1,
        max=16384
    )

    alpha_channel: EnumProperty(
        name="Alpha Channel",
        description=(
            "Channel used when the Alpha input "
            "comes from an Image Texture Color output"
        ),
        items=[
            (
                'LUMINANCE',
                "Luminance",
                "Convert RGB to luminance"
            ),
            (
                'RED',
                "Red",
                "Use the red channel"
            ),
            (
                'GREEN',
                "Green",
                "Use the green channel"
            ),
            (
                'BLUE',
                "Blue",
                "Use the blue channel"
            ),
            (
                'ALPHA',
                "Alpha",
                "Use the source image alpha channel"
            ),
        ],
        default='LUMINANCE'
    )

    generated_image_name: StringProperty(
        name="Generated Image",
        default=""
    )

    @classmethod
    def poll(cls, node_tree):
        return (
            node_tree is not None
            and node_tree.bl_idname == 'ShaderNodeTree'
        )

    def init(self, context):
        self.node_tree = (
            create_material_group()
        )

        self.width = 240

    def draw_buttons(
        self,
        context,
        layout
    ):
        layout.prop(
            self,
            "output_type",
            text="Output Type"
        )

        if self.output_type != 'IMAGE':
            return

        layout.separator()

        layout.prop(
            self,
            "image_name",
            text="Image Name"
        )

        #
        # Only really needed when there is no
        # source image providing dimensions.
        #

        row = layout.row(
            align=True
        )

        row.prop(
            self,
            "image_width",
            text="W"
        )

        row.prop(
            self,
            "image_height",
            text="H"
        )

        layout.prop(
            self,
            "alpha_channel",
            text="Alpha Channel"
        )

        operator = layout.operator(
            SHADER_OT_generate_alpha_image.bl_idname,
            text="Generate / Update Image",
            icon='IMAGE_DATA'
        )

        operator.node_name = self.name

        if self.generated_image_name:
            box = layout.box()

            box.label(
                text=(
                    "Generated: "
                    + self.generated_image_name
                ),
                icon='CHECKMARK'
            )


# ============================================================
# Add menu
# ============================================================

def shader_add_menu(
    self,
    context
):
    space = context.space_data

    if (
        space is None
        or space.tree_type != 'ShaderNodeTree'
    ):
        return

    self.layout.separator()

    operator = self.layout.operator(
        "node.add_node",
        text="Add Alpha To Texture",
        icon='IMAGE_DATA'
    )

    operator.type = (
        ShaderNodeAddAlphaToTexture.bl_idname
    )

    operator.use_transform = True


classes = (
    SHADER_OT_generate_alpha_image,
    ShaderNodeAddAlphaToTexture,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.NODE_MT_add.append(
        shader_add_menu
    )


def unregister():
    try:
        bpy.types.NODE_MT_add.remove(
            shader_add_menu
        )
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
