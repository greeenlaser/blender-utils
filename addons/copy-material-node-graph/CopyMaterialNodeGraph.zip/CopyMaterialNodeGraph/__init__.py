bl_info = {
    "name": "Copy Material Node Graph",
    "author": "greenlaser",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "Shader Editor > Right Click",
    "description": "Copies individual shader nodes or the entire material node graph to the clipboard",
    "category": "Node",
}

import bpy

from bpy.props import StringProperty


addon_keymaps = []

#
# Name of the node that was actually under the cursor
# when RMB opened the context menu.
#
context_node_name = None


def format_value(value):
    try:
        return tuple(value)
    except TypeError:
        return value


def format_node(node, tree):
    lines = []

    lines.append(f"NODE: {node.name}")
    lines.append(f"  Type: {node.bl_idname}")

    # Math / Vector Math operation
    if hasattr(node, "operation"):
        lines.append(f"  Operation: {node.operation}")

    # Map Range properties
    if node.bl_idname == "ShaderNodeMapRange":
        lines.append(f"  Data Type: {node.data_type}")
        lines.append(f"  Interpolation: {node.interpolation_type}")
        lines.append(f"  Clamp: {node.clamp}")

    lines.append("")

    #
    # Inputs
    #

    lines.append("  Inputs:")

    has_input = False

    for index, socket in enumerate(node.inputs):
        has_input = True

        links = [
            link
            for link in tree.links
            if link.to_node == node
            and link.to_socket == socket
        ]

        if links:
            for link in links:
                lines.append(
                    f"    [{index}] {socket.name}"
                    f" <- "
                    f"{link.from_node.name}.{link.from_socket.name}"
                )

        elif hasattr(socket, "default_value"):
            lines.append(
                f"    [{index}] {socket.name}: "
                f"{format_value(socket.default_value)}"
            )

        else:
            lines.append(
                f"    [{index}] {socket.name}"
            )

    if not has_input:
        lines.append("    None")

    lines.append("")

    #
    # Outputs
    #

    lines.append("  Outputs:")

    has_output = False

    for index, socket in enumerate(node.outputs):
        links = [
            link
            for link in tree.links
            if link.from_node == node
            and link.from_socket == socket
        ]

        if links:
            has_output = True

            for link in links:
                lines.append(
                    f"    [{index}] {socket.name}"
                    f" -> "
                    f"{link.to_node.name}.{link.to_socket.name}"
                )

    if not has_output:
        lines.append("    None")

    #
    # Color Ramp
    #

    if node.bl_idname == "ShaderNodeValToRGB":
        lines.append("")

        lines.append(
            f"  Color Ramp Interpolation: "
            f"{node.color_ramp.interpolation}"
        )

        for index, element in enumerate(node.color_ramp.elements):
            lines.append(
                f"  Ramp[{index}]: "
                f"Position={element.position}, "
                f"Color={tuple(element.color)}"
            )

    return lines


def get_material_tree(context):
    if (
        context.object is None
        or context.object.active_material is None
        or not context.object.active_material.use_nodes
    ):
        return None, None

    material = context.object.active_material

    #
    # Use the tree currently being edited.
    #
    # At the material root this is material.node_tree.
    # Inside a node group it becomes that group's tree.
    #

    tree = context.space_data.edit_tree

    if tree is None:
        tree = material.node_tree

    return material, tree


def find_node_at_mouse(context, mouse_x, mouse_y):
    tree = context.space_data.edit_tree

    if tree is None:
        return None

    region = context.region

    if region is None:
        return None

    #
    # Convert region pixel coordinates into node-editor
    # canvas coordinates.
    #

    view_x, view_y = region.view2d.region_to_view(
        mouse_x,
        mouse_y
    )

    candidates = []

    for node in tree.nodes:
        location = node.location_absolute
        dimensions = node.dimensions

        #
        # Node.location_absolute is its upper-left position.
        #

        left = location.x
        right = location.x + dimensions.x

        top = location.y
        bottom = location.y - dimensions.y

        if (
            view_x >= left
            and view_x <= right
            and view_y <= top
            and view_y >= bottom
        ):
            candidates.append(node)

    if not candidates:
        return None

    #
    # Frames can contain other nodes and therefore overlap
    # huge areas. Prefer non-frame nodes.
    #

    non_frames = [
        node
        for node in candidates
        if node.bl_idname != "NodeFrame"
    ]

    if non_frames:
        candidates = non_frames

    #
    # If nodes overlap, prefer the smallest matching node.
    #

    candidates.sort(
        key=lambda node:
            node.dimensions.x * node.dimensions.y
    )

    return candidates[0]


#
# Copy entire current node context
#

class SHADER_OT_copy_material_node_graph(
    bpy.types.Operator
):
    bl_idname = "shader.copy_material_node_graph"
    bl_label = "Copy Material Node Graph"
    bl_description = "Copy the entire current material node graph as text"

    @classmethod
    def poll(cls, context):
        material, tree = get_material_tree(context)

        return (
            context.area is not None
            and context.area.type == 'NODE_EDITOR'
            and context.space_data.tree_type == 'ShaderNodeTree'
            and material is not None
            and tree is not None
        )

    def execute(self, context):
        material, tree = get_material_tree(context)

        lines = [
            f"MATERIAL: {material.name}",
            "",
            "===== NODES =====",
            "",
        ]

        for node in tree.nodes:
            lines.extend(
                format_node(node, tree)
            )

            lines.append("")

        context.window_manager.clipboard = "\n".join(lines)

        self.report(
            {'INFO'},
            "Material node graph copied to clipboard!"
        )

        return {'FINISHED'}


#
# Copy exactly one node
#

class SHADER_OT_copy_node(
    bpy.types.Operator
):
    bl_idname = "shader.copy_node_as_text"
    bl_label = "Copy Node"
    bl_description = "Copy this shader node as text"

    node_name: StringProperty()

    @classmethod
    def poll(cls, context):
        material, tree = get_material_tree(context)

        return (
            context.area is not None
            and context.area.type == 'NODE_EDITOR'
            and context.space_data.tree_type == 'ShaderNodeTree'
            and material is not None
            and tree is not None
        )

    def execute(self, context):
        material, tree = get_material_tree(context)

        node = tree.nodes.get(
            self.node_name
        )

        if node is None:
            self.report(
                {'ERROR'},
                "Node no longer exists"
            )

            return {'CANCELLED'}

        lines = [
            f"MATERIAL: {material.name}",
            "",
        ]

        lines.extend(
            format_node(node, tree)
        )

        context.window_manager.clipboard = "\n".join(lines)

        self.report(
            {'INFO'},
            f"Node '{node.name}' copied to clipboard!"
        )

        return {'FINISHED'}


#
# Capture the RMB position before opening Blender's
# normal NODE_MT_context_menu.
#

class SHADER_OT_material_graph_context_menu(
    bpy.types.Operator
):
    bl_idname = "shader.material_graph_context_menu"
    bl_label = "Shader Node Context Menu"
    bl_options = {'INTERNAL'}

    @classmethod
    def poll(cls, context):
        return (
            context.area is not None
            and context.area.type == 'NODE_EDITOR'
            and context.region is not None
            and context.region.type == 'WINDOW'
        )

    def invoke(self, context, event):
        global context_node_name

        context_node_name = None

        if (
            context.space_data.tree_type == 'ShaderNodeTree'
        ):
            node = find_node_at_mouse(
                context,
                event.mouse_region_x,
                event.mouse_region_y
            )

            if node is not None:
                context_node_name = node.name

        #
        # Open Blender's real context menu.
        #

        bpy.ops.wm.call_menu(
            name="NODE_MT_context_menu"
        )

        return {'FINISHED'}


#
# Append our entries to Blender's normal node menu.
#

def shader_context_menu(self, context):
    global context_node_name

    if (
        context.area is None
        or context.area.type != 'NODE_EDITOR'
        or context.space_data.tree_type != 'ShaderNodeTree'
    ):
        return

    material, tree = get_material_tree(context)

    if material is None or tree is None:
        return

    self.layout.separator()

    #
    # Only appears if RMB was physically over a node.
    #

    if (
        context_node_name is not None
        and tree.nodes.get(context_node_name) is not None
    ):
        operator = self.layout.operator(
            SHADER_OT_copy_node.bl_idname,
            text="Copy Node",
            icon='COPYDOWN'
        )

        operator.node_name = context_node_name

    #
    # Always available.
    #

    self.layout.operator(
        SHADER_OT_copy_material_node_graph.bl_idname,
        text="Copy Material Node Graph",
        icon='COPYDOWN'
    )


classes = (
    SHADER_OT_copy_material_node_graph,
    SHADER_OT_copy_node,
    SHADER_OT_material_graph_context_menu,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.NODE_MT_context_menu.append(
        shader_context_menu
    )

    #
    # Override RMB in the Node Editor so we can capture
    # the actual mouse position before opening Blender's
    # normal context menu.
    #

    window_manager = bpy.context.window_manager

    keyconfig = window_manager.keyconfigs.addon

    if keyconfig is not None:
        keymap = keyconfig.keymaps.new(
            name="Node Editor",
            space_type='NODE_EDITOR',
            region_type='WINDOW'
        )

        keymap_item = keymap.keymap_items.new(
            SHADER_OT_material_graph_context_menu.bl_idname,
            type='RIGHTMOUSE',
            value='PRESS'
        )

        addon_keymaps.append(
            (
                keymap,
                keymap_item
            )
        )


def unregister():
    #
    # Remove addon keymaps.
    #

    for keymap, keymap_item in addon_keymaps:
        keymap.keymap_items.remove(
            keymap_item
        )

    addon_keymaps.clear()

    try:
        bpy.types.NODE_MT_context_menu.remove(
            shader_context_menu
        )
    except Exception:
        pass

    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except RuntimeError:
            pass


if __name__ == "__main__":
    register()
