bl_info = {
    "name": "Copy Material Node Graph",
    "author": "greenlaser",
    "version": (1, 0, 0),
    "blender": (4, 5, 0),
    "location": "Shader Editor > Right Click",
    "description": "Copies the active material shader node graph to the clipboard",
    "category": "Node",
}

import bpy


def format_value(value):
    try:
        return tuple(value)
    except TypeError:
        return value


class SHADER_OT_copy_material_node_graph(bpy.types.Operator):
    bl_idname = "shader.copy_material_node_graph"
    bl_label = "Copy Material Node Graph"
    bl_description = "Copy the active material node graph as text"

    @classmethod
    def poll(cls, context):
        return (
            context.area is not None
            and context.area.type == 'NODE_EDITOR'
            and context.space_data.tree_type == 'ShaderNodeTree'
            and context.object is not None
            and context.object.active_material is not None
            and context.object.active_material.use_nodes
        )

    def execute(self, context):
        material = context.object.active_material
        tree = material.node_tree

        lines = []

        lines.append(f"MATERIAL: {material.name}")
        lines.append("")
        lines.append("===== NODES =====")
        lines.append("")

        for node in tree.nodes:
            lines.append(f"NODE: {node.name}")
            lines.append(f"  Type: {node.bl_idname}")

            # Math / Vector Math operation
            if hasattr(node, "operation"):
                lines.append(f"  Operation: {node.operation}")

            # Map Range properties
            if node.bl_idname == "ShaderNodeMapRange":
                lines.append(f"  Data Type: {node.data_type}")
                lines.append(f"  Interpolation: {node.interpolation_type}")
                lines.append(f"  Clamp: {node.clamp}")

            lines.append("")

            # Inputs
            lines.append("  Inputs:")

            has_input = False

            for index, socket in enumerate(node.inputs):
                has_input = True

                links = [
                    link
                    for link in tree.links
                    if link.to_node == node
                    and link.to_socket == socket
                ]

                if links:
                    for link in links:
                        lines.append(
                            f"    [{index}] {socket.name}"
                            f" <- "
                            f"{link.from_node.name}.{link.from_socket.name}"
                        )

                elif hasattr(socket, "default_value"):
                    lines.append(
                        f"    [{index}] {socket.name}: "
                        f"{format_value(socket.default_value)}"
                    )

                else:
                    lines.append(
                        f"    [{index}] {socket.name}"
                    )

            if not has_input:
                lines.append("    None")

            lines.append("")

            # Outputs
            lines.append("  Outputs:")

            has_output = False

            for index, socket in enumerate(node.outputs):
                links = [
                    link
                    for link in tree.links
                    if link.from_node == node
                    and link.from_socket == socket
                ]

                if links:
                    has_output = True

                    for link in links:
                        lines.append(
                            f"    [{index}] {socket.name}"
                            f" -> "
                            f"{link.to_node.name}.{link.to_socket.name}"
                        )

            if not has_output:
                lines.append("    None")

            # Color Ramp
            if node.bl_idname == "ShaderNodeValToRGB":
                lines.append("")
                lines.append(
                    f"  Color Ramp Interpolation: "
                    f"{node.color_ramp.interpolation}"
                )

                for index, element in enumerate(node.color_ramp.elements):
                    lines.append(
                        f"  Ramp[{index}]: "
                        f"Position={element.position}, "
                        f"Color={tuple(element.color)}"
                    )

            lines.append("")

        result = "\n".join(lines)

        context.window_manager.clipboard = result

        self.report(
            {'INFO'},
            "Material node graph copied to clipboard!"
        )

        return {'FINISHED'}


def shader_context_menu(self, context):
    self.layout.separator()

    self.layout.operator(
        SHADER_OT_copy_material_node_graph.bl_idname,
        icon='COPYDOWN'
    )


classes = (
    SHADER_OT_copy_material_node_graph,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.NODE_MT_context_menu.append(
        shader_context_menu
    )


def unregister():
    bpy.types.NODE_MT_context_menu.remove(
        shader_context_menu
    )

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)


if __name__ == "__main__":
    register()
